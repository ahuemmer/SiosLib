H.-J. Berndt - RS232-Application-Programming-Interface - RSAPI

In diesem Archiv befinden sich die RSAPI.DLL's f�r 16- und 32-Bit-Windows-Systeme aus dem Buch:

H.-J. Berndt / B. Kainka 
Messen, Steuern und Regeln mit Word und Excel 
VBA-Makros f�r die serielle Schnittstelle, 2., neubearb. und erw. Aufl. 
Franzis-Verlag GmbH, 85586 Poing, 1999 ISBN 3-7723-4093-8
Franzis-Verlag: http://www.franzis.de Suchstichwort "BERNDT"

Diese Dateien d�rfen f�r den Privatgebrauch frei kopiert und weitergegeben werden. Kommerzielle Nutzung ist erlaubt, wenn in den Anwendungen der Autor und die Quelle (Buchtitel s.o.) deutlich genannt wird. Die Weitergabe eines ver�nderten Archivs ist untersagt. Die Nutzung erfolgt auf eigene Gefahr. F�r Sch�den an Soft- oder Hardware durch den Einsatz der DLL wird keine Haftung �bernommen. 
------------------------------------------------------------------------
Archivinhalt
------------------------------------------------------------------------
RSAPI32.EXE	- 32-Bit Version 1.1 vom 09.09.1998, 62053 Bytes
RSAPI16.EXE	- 16-Bit Version 1.0 vom 11.06.1997, 35840 Bytes
RSAPI.HLP  	- Hilfedatei f�r beide DLLs vom 8.4.1999
README.TXT	- Dieser Text
------------------------------------------------------------------------
Hinweis:
Durch den Start der selbstentpackenden EXE-Dateien, werden die DLL's ins Windows-Verzeichnis kopiert. 
------------------------------------------------------------------------
Diese DLL bildet die Grundlage des oben genannten Buches. Dort findet man viele Beispielanwendungen f�r Word und Excel in VBA. Alle VBA-Beispiele lassen sich problemlos nach Visual Basic �bertragen. Der Einsatz der DLL unter Delphi (Hilfe: Stichwort Delphi) und C/C++ ist zwar m�glich, aber eher ungew�hnlich, da sich mit diesen Sprachen leicht eigene RS232-Routinen erstellen lassen.

Die DLL unterst�tzt u.a. Produkte der Firma Modulbus: www.modul-bus.de
Dort findet man evtl. weitere Artikel zum Umgang mit der RSAPI.

H.-J. Berndt, Solingen, der 10. Januar 2000

