program Aufzug2P;

uses
  Forms,
  Aufzug2 in 'Aufzug2.pas' {Form1},
  SIOSDLL in 'SIOSDLL.pas';

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(TForm1, Form1);
  Application.Run;
end.
