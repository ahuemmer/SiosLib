unit Aufzug;

interface

uses SIOSDLL,
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, ExtCtrls;

type
  TForm1 = class(TForm)
    Button1: TButton;
    Edit1: TEdit;
    Timer1: TTimer;
    Position: TLabel;
    ScrollBar1: TScrollBar;
    Label1: TLabel;
    Label2: TLabel;
    ScrollBar2: TScrollBar;
    Edit2: TEdit;
    Label3: TLabel;
    procedure Button1Click(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure ScrollBar1Change(Sender: TObject);
    procedure ScrollBar2Change(Sender: TObject);
  end;

var
  Form1: TForm1;
  StepSoll, StepIst, Muster, Anzeige: Integer;
  Phase, Stockwerk: Integer;
  Step : Array  [0..3] of Integer;

implementation

{$R *.DFM}


procedure TForm1.Button1Click(Sender: TObject);
var n: Integer;
begin
     StepSoll := -300;
end;

procedure TForm1.Timer1Timer(Sender: TObject);
var Inp: Integer;
begin
  Inp := Din;
  If (Inp and 1) = 1 then begin
     StepIst := 0;
     StepSoll := 0
  end;
  If (Inp and 2) =2 then begin    {T1}
     StepSoll := 0;
     Anzeige := 128;
  end;
  If (Inp and 4) =4 then begin    {T2}
     StepSoll := Stockwerk;
     Anzeige := 128;
  end;
  If (Inp and 8) =8 then begin    {T3}
     StepSoll := Stockwerk * 2;
     Anzeige := 128;
  end;
  If (Inp and 16) =16 then begin  {T1, Fahrkorb}
     StepSoll := 0;
     Anzeige := 16 + 128;
  end;
  If (Inp and 32) =32 then begin  {T2, Fahrkorb}
     StepSoll := Stockwerk;
     Anzeige := 32 + 128;
  end;
  If (Inp and 64) =64 then begin  {T2, Fahrkorb}
     StepSoll := Stockwerk;
     Anzeige := 32 + 128;
  end;
  If (Inp and 128) =128 then begin  {T3, Fahrkorb}
     StepSoll := Stockwerk * 2;
     Anzeige := 64 + 128;
   end;

  if StepSoll > StepIst then begin;
    StepIst := StepIst + 1;
    Phase := (StepIst mod 4) and 3;
    Dout (Step[Phase] + Anzeige);
  end;
  if StepSoll < StepIst then begin;
    StepIst := StepIst - 1;
    Phase := (StepIst mod 4) and 3;
    Dout (Step[Phase] + Anzeige);
  end;
  if StepIst > -1 then Edit1.Text := FloatToStr (StepIst);
  if StepIst = StepSoll  then begin
     Anzeige :=  0;
     Dout (0);
   end;  
end;

procedure TForm1.FormCreate(Sender: TObject);
var n: Integer;
begin
  n := FINDHARD (1); {Ergebnisanzeige im Fenster}
  Step[0] := 1;
  Step[1] := 2;
  Step[2] := 4;
  Step[3] := 8;
  Timer1.Enabled := true;
  StepSoll := 0;
  StepIst := 0;
  Phase := 0;
  Anzeige := 0;
  Stockwerk := 256;
end;

procedure TForm1.ScrollBar1Change(Sender: TObject);
begin
   Timer1.Interval := ScrollBar1.Position;
end;

procedure TForm1.ScrollBar2Change(Sender: TObject);
begin
  Stockwerk := Scrollbar2.Position;
  Edit2.Text := FloatToStr (Stockwerk);
end;

end.
