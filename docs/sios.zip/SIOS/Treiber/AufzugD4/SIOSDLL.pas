Unit SiosDLL;

interface
const THEDLL='RSAPI.DLL';

function INITSIOS (COM: WORD):Integer;
         stdcall external THEDLL;
function INITCOMPULAB (COM: WORD):Integer;
         safecall  external THEDLL;
function FINDHARD( i:Integer):integer; stdcall; external THEDLL;
function AIN(i:Integer):integer;  stdcall; external THEDLL;
procedure DOUT(d:WORD);
         stdcall external THEDLL;
function DIN:Integer;
         stdcall external THEDLL;
function OPENCOM( s:AnsiString):integer; stdcall; external THEDLL;
function CLOSECOM():Integer;
         stdcall external THEDLL;
function READBYTE: integer; stdcall; external THEDLL;
function SENDBYTE(i:integer): integer; stdcall; external THEDLL;
function DELAY(i:integer): integer; stdcall; external THEDLL;
procedure TIMEINIT; stdcall; external THEDLL;
function TIMEREAD: longint; stdcall; external THEDLL;


implementation

end.
