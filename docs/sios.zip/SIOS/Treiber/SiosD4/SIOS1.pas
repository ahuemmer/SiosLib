unit SIOS1;

interface

uses  SIOSDLL,
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  ExtCtrls, StdCtrls;

type
  TForm1 = class(TForm)
    Edit1: TEdit;
    Timer1: TTimer;
    procedure FormCreate(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
  end;

var
  Form1: TForm1;

implementation

{$R *.DFM}


procedure TForm1.FormCreate(Sender: TObject);
begin
 OpenCom(Pchar('com2:19200,N,8,1'));
  SendByte (16);
  SendByte (85);
  SendByte (48);
  Edit1.Text:= (FloatToStr (ReadByte));
end;

procedure TForm1.Timer1Timer(Sender: TObject);
begin
  SendByte (48);
  Edit1.Text:= (FloatToStr (ReadByte));
end;

end.
