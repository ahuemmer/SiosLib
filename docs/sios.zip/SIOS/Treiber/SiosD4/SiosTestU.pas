unit SiosTestU;

interface

uses SIOSDLL,
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, ExtCtrls;

type
  TForm1 = class(TForm)
    Button2: TButton;
    Edit1: TEdit;
    Button3: TButton;
    Timer1: TTimer;
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
  end;

var
  Form1: TForm1;

implementation

{$R *.DFM}


procedure TForm1.Button2Click(Sender: TObject);
var n: Integer;
begin
  n := INITSIOS(2);  {COM2}
  DOUT (15);
  Edit1.Text := FloatToStr (Ain(1));
  CloseCOM;
end;

procedure TForm1.Button3Click(Sender: TObject);
var n: Integer;
begin
  n := FINDHARD (1); {Ergebnisanzeige im Fenster}
  DOUT (240);
  Timer1.Enabled := true;
end;

procedure TForm1.Timer1Timer(Sender: TObject);
begin
  Edit1.Text := FloatToStr (Ain(1));
end;

end.
