program SIOStest;

uses
  Forms,
  SiosTestU in 'SiosTestU.pas' {Form1},
  SIOSDLL in 'SIOSDLL.pas';

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(TForm1, Form1);
  Application.Run;
end.
