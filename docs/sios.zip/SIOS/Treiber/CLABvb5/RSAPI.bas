Attribute VB_Name = "Module1"
Declare Function OPENCOM Lib "RSAPI" (ByVal A$) As Integer
Declare Function INITCOMPULAB Lib "RSAPI" (ByVal COM%) As Integer
Declare Function FINDHARD Lib "RSAPI" (ByVal Meldung%) As Integer
Declare Sub CLOSECOM Lib "RSAPI" ()
Declare Sub SENDBYTE Lib "RSAPI" (ByVal b%)
Declare Function READBYTE Lib "RSAPI" () As Integer
Declare Sub DOUT Lib "RSAPI" (ByVal Wert%)
Declare Function DIN Lib "RSAPI" () As Integer
Declare Function AIN Lib "RSAPI" (ByVal Eingang%) As Integer
Declare Sub DELAY Lib "RSAPI" (ByVal b%)
Declare Sub TIMEINIT Lib "RSAPI" ()
Declare Function TIMEREAD Lib "RSAPI" () As Long

